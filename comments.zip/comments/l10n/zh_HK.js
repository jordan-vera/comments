OC.L10N.register(
    "comments",
    {
    "Cancel" : "取消",
    "Save" : "儲存"
},
"nplurals=1; plural=0;");
