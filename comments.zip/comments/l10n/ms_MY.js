OC.L10N.register(
    "comments",
    {
    "Cancel" : "Batal",
    "Save" : "Simpan"
},
"nplurals=1; plural=0;");
