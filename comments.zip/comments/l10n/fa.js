OC.L10N.register(
    "comments",
    {
    "Comments" : "نظرات",
    "Edit comment" : "ویرایش توضیح",
    "Delete comment" : "حذف توضیح",
    "New comment …" : "توضیح جدید ...",
    "Post" : "ارسال",
    "Cancel" : "منصرف شدن",
    "[Deleted user]" : "[کاربر حذف شده]",
    "No comments yet, start the conversation!" : "هنوز هیچ نظری ندارید ، مکالمه را شروع کنید!",
    "More comments …" : "نظرات بیشتر...",
    "Save" : "ذخیره",
    "Allowed characters {count} of {max}" : "شخصیت های مجاز {count} از {max",
    "Error occurred while retrieving comment with ID {id}" : "هنگام بازیابی نظر با ID {id Er خطایی رخ داد",
    "Error occurred while updating comment with id {id}" : "هنگام به روزرسانی نظر با شناسه شناسه Er خطایی روی داد",
    "Error occurred while posting comment" : "هنگام ارسال نظر خطایی روی داد",
    "Comment" : "نظر"
},
"nplurals=2; plural=(n > 1);");
