OC.L10N.register(
    "comments",
    {
    "Cancel" : "ۋاز كەچ",
    "Save" : "ساقلا"
},
"nplurals=1; plural=0;");
