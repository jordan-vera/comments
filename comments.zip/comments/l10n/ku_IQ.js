OC.L10N.register(
    "comments",
    {
    "Cancel" : "لابردن",
    "Save" : "پاشکه‌وتکردن"
},
"nplurals=2; plural=(n != 1);");
